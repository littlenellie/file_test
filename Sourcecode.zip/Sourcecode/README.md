
  # Invoice Dashboard for Payments

  This is a code bundle for Invoice Dashboard for Payments. The original project is available at https://www.figma.com/design/cNtLQdmt0Pc61t7oU0X8Lz/Invoice-Dashboard-for-Payments.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  